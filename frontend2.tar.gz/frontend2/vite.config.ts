import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'


// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
<<<<<<< HEAD
<<<<<<< HEAD
})
=======
=======
>>>>>>> e16aac80bedd4c0c7edbc3831a88d5967b65c92e
  server: {
    proxy: {
      "/api/": {
        target: "http://localhost:9109",
        changeOrigin: true,
        secure: false,
        ws: true
      }
    }
  }
})
<<<<<<< HEAD
>>>>>>> 9e397c69e687744028fb19cfb92bfaed8f387153
=======
>>>>>>> e16aac80bedd4c0c7edbc3831a88d5967b65c92e
