
export const Home = () => {
    return <div style={{height: "100%"}}>
        <div style={{display: "flex", flexDirection: "column", justifyContent: "center"}}>

            <h1 className="fw-bold">Welcome to ClassTrivia!</h1>
            <p>A class quiz platform for students. A gamified learning environment.</p>
        </div>
    </div>
}