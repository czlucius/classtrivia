export const NotFound404 = () => {
    return <div>
        <h1>404 Not found!</h1>
        <a href="/">Return to homepage </a>
    </div>
}