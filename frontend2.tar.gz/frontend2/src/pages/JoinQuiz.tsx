export const JoinQuiz = () => {
    return <div>

    </div>
}