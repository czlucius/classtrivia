export class Player {
    userid: string;
    name: string;
    username: string;
    class: string;
}

// module.exports = Player